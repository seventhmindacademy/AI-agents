"""Agent-ஓட கைகள் (tools). Demo data – replace with real APIs later."""
HOTELS = [{"name": "Hotel A", "area": "Lake view", "price": 6500},
          {"name": "Hotel B", "area": "Town centre", "price": 5000},
          {"name": "Hotel C", "area": "Cozy cottage", "price": 3500}]
TRANSPORT = {"bus": 2400, "train": 3200}
WEATHER = {"saturday": "rain 70%", "sunday": "sunny"}

def get_weather(day: str) -> str:
    """Get the weather forecast in Ooty for a day (saturday or sunday)."""
    return WEATHER.get(day.lower(), "unknown")

def search_transport(people: int) -> dict:
    """Get bus and train prices from Chennai to Ooty for a group."""
    return {mode: price * people // 4 for mode, price in TRANSPORT.items()}

def search_hotels(max_price: int) -> list:
    """Find Ooty hotels for 2 nights that cost at most max_price rupees."""
    return [h for h in HOTELS if h["price"] <= max_price]

def calculate_budget(transport: int, hotel: int, food: int = 2500) -> dict:
    """Add transport, hotel and food costs and return the total in rupees."""
    total = transport + hotel + food
    return {"total": total, "within_10000": total <= 10000}
