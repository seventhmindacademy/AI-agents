# 🤖 Tamil Trip Agent – your first AI Agent
Seventh Mind Academy · Episode 5 · Python + Gemini API (function calling) + Gradio

**Brain** = Gemini · **Hands** = the Python functions in `tools.py` · **Loop** = Gemini automatically calls tools until the plan is ready.

## Run on your laptop
```
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```
Copy `.env.example` to `.env`, paste your free key from https://aistudio.google.com/apikey, then:
```
python agent.py      # terminal version
python app.py        # web app at http://127.0.0.1:7860
```

## Deploy online (Hugging Face Spaces, free tier)
1. Create a free account at huggingface.co → **New Space** → SDK: **Gradio** → Public.
2. Upload `app.py`, `agent.py`, `tools.py`, `requirements.txt` (NOT `.env`).
3. Space **Settings → Variables and secrets → New secret**: name `GEMINI_API_KEY`, value = your key.
4. The Space builds automatically and gives you a public link that works on any phone.

## Safety
- The agent only *plans* and asks "Book பண்ணட்டுமா?". It never books or pays by itself.
- Prices, hotels and weather in `tools.py` are demo data. Replace them with real APIs before real use.
- Keep your API key in Secrets / `.env`, never in the code.
