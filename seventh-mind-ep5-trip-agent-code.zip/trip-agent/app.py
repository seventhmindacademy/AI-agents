"""Web app for the agent – runs locally or on Hugging Face Spaces."""
import gradio as gr
from agent import run_agent

def chat(message, history):
    return run_agent(message)

app = gr.ChatInterface(fn=chat, title="🤖 Tamil Trip Agent",
                       description="Seventh Mind Academy – AI Agent demo (tools + Gemini)",
                       examples=["4 பேருக்கு, ₹10,000 budget-ல, இந்த weekend Ooty trip plan பண்ணு"])
if __name__ == "__main__":
    app.launch()
