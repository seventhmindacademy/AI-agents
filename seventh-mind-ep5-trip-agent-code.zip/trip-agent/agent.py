"""Mini AI Agent: Gemini (மூளை) + tools (கைகள்) + automatic loop."""
from dotenv import load_dotenv
from google import genai
from google.genai import types
from tools import get_weather, search_transport, search_hotels, calculate_budget

load_dotenv()
client = genai.Client()
MODEL = "gemini-2.5-flash"   # change if Google AI Studio lists a newer model

RULES = ("நீ ஒரு travel agent. Tools-ஐ use பண்ணி plan போடு. Budget-ஐ தாண்டினா மலிவான option-ஐ தேர்ந்தெடு. "
         "மழை நாள்ல indoor இடங்கள் சொல்லு. கடைசியில 'Book பண்ணட்டுமா?'ன்னு கேளு. எதையும் தானா book பண்ணாதே.")

def run_agent(task: str) -> str:
    response = client.models.generate_content(
        model=MODEL,
        contents=task,
        config=types.GenerateContentConfig(
            system_instruction=RULES,
            tools=[get_weather, search_transport, search_hotels, calculate_budget],  # Gemini decides when to call them
        ),
    )
    return response.text

if __name__ == "__main__":
    print(run_agent("4 பேருக்கு, ₹10,000 budget-ல, இந்த weekend Ooty trip plan பண்ணு"))
